#include <jni.h>
#include <android/log.h>

#define LOG_TAG "NativeBridge"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

static JavaVM* g_vm = NULL;
static jobject g_callback = NULL;
static jmethodID g_method = NULL;

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    g_vm = vm;
    JNIEnv* env;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }
    return JNI_VERSION_1_6;
}

extern "C" void update_java_data(int fps, int drawCalls, int totalFrames) {
    if (g_vm == NULL || g_callback == NULL || g_method == NULL) return;
    
    JNIEnv* env;
    int attach = g_vm->GetEnv((void**)&env, JNI_VERSION_1_6);
    bool attached = false;
    if (attach == JNI_EDETACHED) {
        if (g_vm->AttachCurrentThread(&env, NULL) != 0) return;
        attached = true;
    }
    
    env->CallVoidMethod(g_callback, g_method, fps, drawCalls, totalFrames);
    
    if (attached) {
        g_vm->DetachCurrentThread();
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_myhook_app_NativeBridge_nativeSetCallback(JNIEnv* env, jclass clazz, jobject callback) {
    if (g_callback != NULL) {
        env->DeleteGlobalRef(g_callback);
        g_callback = NULL;
    }
    if (callback != NULL) {
        g_callback = env->NewGlobalRef(callback);
        jclass cls = env->GetObjectClass(g_callback);
        g_method = env->GetMethodID(cls, "onNativeData", "(III)V");
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_myhook_app_NativeBridge_nativeStartHook(JNIEnv* env, jclass clazz) {
    LOGI("Hook start signal received from Java");
}

#include <android/log.h>

#define LOG_TAG "GraphicsHook"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" void setup_graphics_hooks();

__attribute__((constructor))
void on_library_load() {
    LOGI("=== Graphics Hook Library Loaded ===");
    setup_graphics_hooks();
}

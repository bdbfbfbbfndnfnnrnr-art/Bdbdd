#include <link.h>
#include <elf.h>
#include <dlfcn.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <android/log.h>
#include <stdint.h>

#define LOG_TAG "GraphicsHook"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#ifdef __LP64__
    #define ELF_R_SYM ELF64_R_SYM
    #define ELF_R_TYPE ELF64_R_TYPE
#else
    #define ELF_R_SYM ELF32_R_SYM
    #define ELF_R_TYPE ELF32_R_TYPE
#endif

struct HookInfo {
    const char* library_name;
    const char* symbol_name;
    void* new_func;
    void** old_func;
    bool found;
};

static int find_symbol_callback(struct dl_phdr_info* info, size_t size, void* data) {
    HookInfo* hook = (HookInfo*)data;
    
    if (info->dlpi_name == NULL || strstr(info->dlpi_name, hook->library_name) == NULL) {
        return 0;
    }
    
    LOGI("Found: %s at %p", info->dlpi_name, (void*)info->dlpi_addr);
    
    ElfW(Addr) base = info->dlpi_addr;
    const ElfW(Phdr)* phdr = info->dlpi_phdr;
    ElfW(Addr) dynamic_vaddr = 0;
    
    for (int i = 0; i < info->dlpi_phnum; i++) {
        if (phdr[i].p_type == PT_DYNAMIC) {
            dynamic_vaddr = phdr[i].p_vaddr;
            break;
        }
    }
    
    if (dynamic_vaddr == 0) return 0;
    
    ElfW(Dyn)* dynamic = (ElfW(Dyn)*)(base + dynamic_vaddr);
    ElfW(Sym)* symtab = NULL;
    const char* strtab = NULL;
    void* jmprel = NULL;
    size_t pltrelsz = 0;
    int pltrel_type = 0;
    
    for (ElfW(Dyn)* d = dynamic; d->d_tag != DT_NULL; d++) {
        switch (d->d_tag) {
            case DT_SYMTAB: symtab = (ElfW(Sym)*)(base + d->d_un.d_ptr); break;
            case DT_STRTAB: strtab = (const char*)(base + d->d_un.d_ptr); break;
            case DT_JMPREL: jmprel = (void*)(base + d->d_un.d_ptr); break;
            case DT_PLTRELSZ: pltrelsz = d->d_un.d_val; break;
            case DT_PLTREL: pltrel_type = d->d_un.d_val; break;
        }
    }
    
    if (!symtab || !strtab || !jmprel || pltrelsz == 0) return 0;
    
    size_t entry_size = (pltrel_type == DT_RELA) ? sizeof(ElfW(Rela)) : sizeof(ElfW(Rel));
    size_t count = pltrelsz / entry_size;
    
    for (size_t i = 0; i < count; i++) {
        ElfW(Addr) offset;
        ElfW(Xword) sym_idx;
        
        if (pltrel_type == DT_RELA) {
            ElfW(Rela)* rel = &((ElfW(Rela)*)jmprel)[i];
            offset = rel->r_offset;
            sym_idx = ELF_R_SYM(rel->r_info);
        } else {
            ElfW(Rel)* rel = &((ElfW(Rel)*)jmprel)[i];
            offset = rel->r_offset;
            sym_idx = ELF_R_SYM(rel->r_info);
        }
        
        const char* name = strtab + symtab[sym_idx].st_name;
        
        if (strcmp(name, hook->symbol_name) == 0) {
            void** got_entry = (void**)(base + offset);
            if (hook->old_func) *hook->old_func = *got_entry;
            
            size_t page_size = sysconf(_SC_PAGESIZE);
            void* page_start = (void*)(((uintptr_t)got_entry) & ~(page_size - 1));
            mprotect(page_start, page_size, PROT_READ | PROT_WRITE);
            
            *got_entry = hook->new_func;
            hook->found = true;
            
            LOGI("Hooked: %s", hook->symbol_name);
            return 1;
        }
    }
    return 0;
}

extern "C" bool hook_pltgot(const char* library_name, const char* symbol_name, 
                            void* new_func, void** old_func) {
    HookInfo hook = {library_name, symbol_name, new_func, old_func, false};
    dl_iterate_phdr(find_symbol_callback, &hook);
    return hook.found;
}

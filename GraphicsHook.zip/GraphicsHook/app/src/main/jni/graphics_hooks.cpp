#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <android/log.h>
#include <time.h>

#define LOG_TAG "GraphicsHook"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" void update_java_data(int fps, int drawCalls, int totalFrames);

static EGLBoolean (*orig_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface) = NULL;
static void (*orig_glClear)(GLbitfield mask) = NULL;
static void (*orig_glDrawElements)(GLenum mode, GLsizei count, GLenum type, const void* indices) = NULL;
static void (*orig_glDrawArrays)(GLenum mode, GLint first, GLsizei count) = NULL;

static int s_frames = 0;
static int s_drawCalls = 0;
static clock_t s_lastTime = 0;
static int s_currentFps = 0;

EGLBoolean my_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    s_frames++;
    clock_t now = clock();
    if (s_lastTime == 0) s_lastTime = now;
    
    if ((now - s_lastTime) >= CLOCKS_PER_SEC) {
        s_currentFps = s_frames;
        update_java_data(s_currentFps, s_drawCalls, s_frames);
        s_frames = 0;
        s_drawCalls = 0;
        s_lastTime = now;
    }
    return orig_eglSwapBuffers(dpy, surface);
}

void my_glClear(GLbitfield mask) {
    orig_glClear(mask);
}

void my_glDrawElements(GLenum mode, GLsizei count, GLenum type, const void* indices) {
    s_drawCalls++;
    orig_glDrawElements(mode, count, type, indices);
}

void my_glDrawArrays(GLenum mode, GLint first, GLsizei count) {
    s_drawCalls++;
    orig_glDrawArrays(mode, first, count);
}

extern "C" bool hook_pltgot(const char* lib, const char* sym, void* new_func, void** old_func);

extern "C" void setup_graphics_hooks() {
    LOGI("Starting graphics hooks...");
    hook_pltgot("libEGL.so", "eglSwapBuffers", (void*)my_eglSwapBuffers, (void**)&orig_eglSwapBuffers);
    hook_pltgot("libGLESv2.so", "glClear", (void*)my_glClear, (void**)&orig_glClear);
    hook_pltgot("libGLESv2.so", "glDrawElements", (void*)my_glDrawElements, (void**)&orig_glDrawElements);
    hook_pltgot("libGLESv2.so", "glDrawArrays", (void*)my_glDrawArrays, (void**)&orig_glDrawArrays);
    LOGI("All hooks registered");
}

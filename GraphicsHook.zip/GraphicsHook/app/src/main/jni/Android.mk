LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE    := graphics_hook
LOCAL_SRC_FILES := hook_engine.cpp graphics_hooks.cpp entry.cpp native_bridge.cpp
LOCAL_LDLIBS    := -llog -lEGL -lGLESv2
LOCAL_CFLAGS    := -O2 -fvisibility=hidden

include $(BUILD_SHARED_LIBRARY)

package com.myhook.app;

public class NativeBridge {
    
    public interface NativeCallback {
        void onNativeData(int fps, int drawCalls, int totalFrames);
    }
    
    static {
        System.loadLibrary("graphics_hook");
    }
    
    private static NativeCallback sCallback;
    
    public static void setCallback(NativeCallback callback) {
        sCallback = callback;
        nativeSetCallback(new NativeReceiver());
    }
    
    public static void startHook() {
        nativeStartHook();
    }
    
    // Called from C++ via JNI
    public static void onFrameData(int fps, int drawCalls, int totalFrames) {
        if (sCallback != null) {
            sCallback.onNativeData(fps, drawCalls, totalFrames);
        }
    }
    
    // Inner class used as JNI callback target
    public static class NativeReceiver {
        @SuppressWarnings("unused")
        public void onNativeData(int fps, int drawCalls, int totalFrames) {
            NativeBridge.onFrameData(fps, drawCalls, totalFrames);
        }
    }
    
    private static native void nativeSetCallback(Object callback);
    private static native void nativeStartHook();
}
